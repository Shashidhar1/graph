import { Component, OnInit, ViewChild } from '@angular/core';


@Component({
    selector: 'app-root',
    templateUrl: './app.component.html'
})
export class AppComponent implements OnInit {

    public ngOnInit(): void {
    }
}